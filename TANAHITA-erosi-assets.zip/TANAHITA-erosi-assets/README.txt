TANAHITA — Asset Foto Erosi

Upload folder "erosi-assets" ini ke ROOT repository TANAHITA.

Struktur yang dibutuhkan:
Tanahita/
├── erosi.html
├── style.css
├── script.js
└── erosi-assets/
    ├── erosi-01-lembar.jpg
    ├── erosi-02-alur.jpg
    ├── erosi-03-parit.jpg
    ├── erosi-04-tebing.jpg
    ├── erosi-05-longsor.jpg
    ├── erosi-06-internal.jpg
    └── erosi-07-percikan.jpg

Nama file sengaja disamakan dengan src yang sudah dipakai erosi.html.
Tidak perlu mengubah erosi.html.
